from .main import obfuscator
