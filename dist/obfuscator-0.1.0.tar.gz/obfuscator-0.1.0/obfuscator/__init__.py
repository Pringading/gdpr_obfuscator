from .main import hello, obfuscator
